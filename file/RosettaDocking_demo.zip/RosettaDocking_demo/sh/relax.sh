# ! bin/bash
# Using "nohup sh sh/relax.sh &"

touch ./nohup.out
cat /dev/null > ./nohup.out
echo

rm -rf relax
mkdir relax

#Generate Log Files
touch relax/LOG.log

echo -e "\n ###################\n\n" >>  ./nohup.out
echo -e "\n\nStart From:" >> ./nohup.out
date >> ./nohup.out
echo -e "\n\n"  >> ./nohup.out

#####################
# Entering 'relax'
#####################
cd ./relax

rm -rf PDB_output
rm -rf score_output


mkdir PDB_output
mkdir PDB_output/ChainL
mkdir PDB_output/ChainR

mkdir score_output
mkdir score_output/ChainL
mkdir score_output/ChainR
 
#Run relax of L.PDB
$RosettaHOME/relax.static.linuxgccrelease @../flag/relax_flag_ChainL

echo -e "\n\n#############\n\nChainL Done: " >> ../nohup.out
date >> ../nohup.out
echo -e "\n\n#############\n\n" >> ../nohup.out

#Run relax of R.PDB
$RosettaHOME/relax.static.linuxgccrelease @../flag/relax_flag_ChainR


cd ../
#####################
# Exit 'relax'
#####################
echo -e "\n\nChainR Done:" >> ./nohup.out
date >> ./nohup.out

echo -e "\n\nALL THE RELAX DONE\n\n" >>  ./nohup.out
echo -e "\n\n######################\n\n" >> ./nohup.out

###########
Generate list of ensemble files
###########
#! bin/bash

cd relax/PDB_output/ChainL
rm -f ensemble.list
filelist1=""
for file in `ls`
	do
	filename=`realpath $file`
	filelist1=$filelist1"\n"$filename
	done
echo "$filelist1" > ensemble.list
cd ../../../

cd relax/PDB_output/ChainR
rm -f ensemble.list
filelist2=""
for file in `ls`
	do
	filename=`realpath $file`
	filelist2=$filelist2"\n"$filename
	done
echo "$filelist2" > ensemble.list
cd ../../../


cat ./nohup.out > relax/LOG.log
cat /dev/null > ./nohup.out

rm -rf relax/PDB_output_backup
cp -r relax/PDB_output relax/PDB_output_backup

