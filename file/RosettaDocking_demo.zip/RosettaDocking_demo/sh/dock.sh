# ! bin/bash
# Using "nohup sh sh/dock.sh &"

touch ./nohup.out
cat /dev/null > ./nohup.out
echo

rm -rf docking
mkdir docking

#Generate Log Files
touch docking/LOG.log

echo -e "\n ###################\n\n" >>  ./nohup.out
echo -e "\n\nStart From:" >> ./nohup.out
date >> ./nohup.out
echo -e "\n\n"  >> ./nohup.out

#####################
# Entering 'docking'
#####################
cd ./docking

rm -rf output
mkdir output

#input�������ֵ�˳��Ӧ��ensemble1��ensemble2��˳��һ�£�����-partners ����˳��һ��

$RosettaHOME/docking_prepack_protocol.static.linuxgccrelease @../flag/docking_prepack_flag

$RosettaHOME/docking_protocol.static.linuxgccrelease @../flag/docking_flag

cd ../
#####################
# Exit 'docking'
#####################
echo -e "To:" >> ./nohup.out
date >> ./nohup.out

echo -e "\n\nALL THE RELAX DONE\n\n" >>  ./nohup.out
echo -e "\n\n######################\n\n" >> ./nohup.out

cat ./nohup.out > docking/LOG.log
cat /dev/null > ./nohup.out

