#! /bin/bash
#Using command "nohup sh run_FEP.sh & > nohup.out"

sh FEP_sh/1_create_mdp_and_sh.sh
cat nohup.out > create_mdp_and_sh.log
cat /dev/null > nohup.out

sh FEP_sh/2_pre_eq.sh
sh FEP_sh/3_runmd.sh
sh FEP_sh/4_analyse.sh

mv create_mdp_and_sh.log log/ -f
cat nohup.out > log/analyse.log
cat /dev/null > nohup.out

