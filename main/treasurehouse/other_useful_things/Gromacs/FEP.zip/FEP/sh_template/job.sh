#!/bin/bash

# Set some environment variables 
FREE_ENERGY=../../../..

MDP=$FREE_ENERGY/00_output/mdp


TOP=$FREE_ENERGY/top/pro1.top

GRO=$FREE_ENERGY/00_output/md_pre/pre.gro

LAMBDA=0


# A new directory will be created for each value of lambda and
# at each step in the workflow for maximum organization.

mkdir result
cd result
mkdir Lambda_$LAMBDA
cd Lambda_$LAMBDA

#################################
# ENERGY MINIMIZATION 1: STEEP  #
#################################
echo "Starting minimization for lambda = $LAMBDA..." 

mkdir EM_1 
cd EM_1


# Iterative calls to grompp and mdrun to run the simulations

gmx grompp -f $MDP/em_steep_$LAMBDA.mdp -c $GRO -p $TOP -o min1_$LAMBDA.tpr

gmx mdrun -nb gpu -v -deffnm min1_$LAMBDA

sleep 10

#################################
# ENERGY MINIMIZATION 2: L-BFGS #
#################################

cd ../
mkdir EM_2
cd EM_2

# We use -maxwarn 1 here because grompp incorrectly complains about use of a plain cutoff; this is a minor issue
# that will be fixed in a future version of Gromacs
gmx grompp -f $MDP/em_l-bfgs_$LAMBDA.mdp -c ../EM_1/min1_$LAMBDA.gro -p $TOP -o min2_$LAMBDA.tpr -maxwarn 1

# Run L-BFGS in serial (cannot be run in parallel)

gmx mdrun -nb gpu -v -deffnm min2_$LAMBDA

echo "Minimization complete."

sleep 10

#####################
# NVT EQUILIBRATION #
#####################
echo "Starting constant volume equilibration..."

cd ../
mkdir NVT
cd NVT

gmx grompp -f $MDP/nvt_$LAMBDA.mdp -c ../EM_2/min2_$LAMBDA.gro -p $TOP -o nvt_$LAMBDA.tpr

gmx mdrun -nb gpu -v -deffnm nvt_$LAMBDA

echo "Constant volume equilibration complete."

sleep 10

#####################
# NPT EQUILIBRATION #
#####################
echo "Starting constant pressure equilibration..."

cd ../
mkdir NPT
cd NPT

gmx grompp -f $MDP/npt_$LAMBDA.mdp -c ../NVT/nvt_$LAMBDA.gro -p $TOP -t ../NVT/nvt_$LAMBDA.cpt -o npt_$LAMBDA.tpr

gmx mdrun -nb gpu -v -deffnm npt_$LAMBDA

echo "Constant pressure equilibration complete."

sleep 10

#################
# PRODUCTION MD #
#################
echo "Starting production MD simulation..."

cd ../
mkdir Production_MD
cd Production_MD

gmx grompp -f $MDP/md_$LAMBDA.mdp -c ../NPT/npt_$LAMBDA.gro -p $TOP -t ../NPT/npt_$LAMBDA.cpt -o md_$LAMBDA.tpr

gmx mdrun -nb gpu -v -deffnm md_$LAMBDA

echo "Production MD complete."

# End
echo "Ending. Job completed for lambda = $LAMBDA"
