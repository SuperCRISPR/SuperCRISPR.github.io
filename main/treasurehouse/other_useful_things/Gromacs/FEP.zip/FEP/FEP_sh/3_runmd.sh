#! /bin/bash
# Using "nohup sh sh/run_md.sh & "
#3rd step
#should be executed at the upper directory (HOME dir)

cd FEP_output

START_LAMBDA=0
END_LAMBDA=20


for ((LAMBDA_CURRENT=$START_LAMBDA;LAMBDA_CURRENT<=$END_LAMBDA;LAMBDA_CURRENT++))
do
JOB_SH=sh_lambda/job_${LAMBDA_CURRENT}.sh
echo -e "\n${JOB_SH} is running (totally ${END_LAMBDA} jobs)" >> ../log/main.log
echo -e "Start From:" >> ../log/main.log
date >> ../log/main.log
sh ${JOB_SH} >> ../log/lambda_${LAMBDA_CURRENT}.log
echo -e "To:" >> ../log/main.log
date >> ../log/main.log
cat ../nohup.out > ../log/nohup/${LAMBDA_CURRENT}.log
cat /dev/null > ../nohup.out
done

echo -e "\nALL THE JOBS DONE\n\nFrom lambda=${START_LAMBDA}\nTo lambda=${END_LAMBDA}\n\n" >>  ../log/main.log
