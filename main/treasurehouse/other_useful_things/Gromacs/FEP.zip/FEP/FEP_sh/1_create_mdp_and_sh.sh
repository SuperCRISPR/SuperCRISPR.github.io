#! /bin/bash
# 1st step
#should be executed at the upper directory (HOME dir)

mkdir FEP_output
cd FEP_output

rm -f -r mdp
mkdir mdp
cp ../mdp_template/*.mdp mdp/

perl ../perl/write_mdp.pl mdp/em_steep.mdp
perl ../perl/write_mdp.pl mdp/em_l-bfgs.mdp
perl ../perl/write_mdp.pl mdp/nvt.mdp
perl ../perl/write_mdp.pl mdp/npt.mdp
perl ../perl/write_mdp.pl mdp/md.mdp

rm -f -r mdp/em_steep.mdp
rm -f -r mdp/em_l-bfgs.mdp
rm -f -r mdp/nvt.mdp
rm -f -r mdp/npt.mdp
rm -f -r mdp/md.mdp

rm -f -r sh_lambda
mkdir sh_lambda
cp ../sh_template/*.sh sh_lambda/

perl ../perl/write_sh.pl sh_lambda/job.sh

rm -f -r sh_lambda/job.sh

