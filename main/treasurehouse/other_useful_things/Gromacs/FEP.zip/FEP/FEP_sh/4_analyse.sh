#! /bin/bash
# 4th step
#should be executed at the upper directory (HOME dir)


#---------------------
#Copying all .xvg output of MD simulation
#---------------------

cd FEP_output

rm FEP -f -r
mkdir FEP
mkdir FEP/mdout_xvg

cd result
for df in  ./*
do
cp $df/Production_MD/md_*.xvg ../FEP/mdout_xvg/
echo -e "copying ${df}"
done

cd ../

for i in  FEP/mdout_xvg/*
do
echo -e "${i} is successfully copied"
done

#-----------------------
#using 'gmx bar' to plot
#-----------------------

cd FEP
mkdir xvg_result
gmx bar -f mdout_xvg/md*.xvg -o xvg_result/bar.xvg -oi xvg_result/bar_int.xvg -oh xvg_result/histogram.xvg > xvg_result/energy.dat
