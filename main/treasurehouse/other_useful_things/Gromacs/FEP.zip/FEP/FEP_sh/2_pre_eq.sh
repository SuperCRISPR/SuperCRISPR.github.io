#! /bin/bash
# Using "nohup sh sh/run_md.sh & "
# 2 md step
#should be executed at the upper directory (HOME dir)

cd FEP_output
rm -r -f ../log
mkdir ../log
mkdir ../log/nohup

rm -r -f md_pre
mkdir md_pre

echo -e "\npreprocess is running" >> ../log/main.log
echo -e "Start From:" >> ../log/main.log
date >> ../log/main.log

gmx grompp -f ../mdp_template/pre.mdp -c ../input/md1.gro -t ../input/md1.cpt -p ../top/pro1.top -o md_pre/pre.tpr
gmx mdrun -deffnm md_pre/pre -nb gpu -v -s md_pre/pre.tpr 

echo -e "To:" >> ../log/main.log
date >> ../log/main.log

cat ../nohup.out > ../log/nohup/preprocess.log
cat /dev/null > ../nohup.out
